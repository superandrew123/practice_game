var Game = React.createClass({

  render: function() {
    return (<div>
        Test
      </div>);
  }
});
